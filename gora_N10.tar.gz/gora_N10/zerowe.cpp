#include <iostream>

using namespace std;

double det (double lambda)
{
    // cout << lambda << endl;
    return 56 - 46*lambda + 12*lambda*lambda - lambda*lambda*lambda;
}

double pochDet (double lambda)
{
    return -46 + 24*lambda - 3*lambda*lambda;
}

double poch2Det (double lambda)
{
    return 24 - 6*lambda;
}

int main()
{
    double solve[3];
    int found = 0;
    int from = -10., to = 10.;
    double accuracy = 0.00000001;
    int counter = 0;
    double x_1, x_2, x_3;

// Bisekcja

    while(found != 3)
    {
        do
        {
            x_1 = ( (double)rand() / (double)RAND_MAX )* (to-from) + from;
            x_2 = ( (double)rand() / (double)RAND_MAX )* (to-from) + from;
        } while(det(x_1)*det(x_2)>=0);

        // cout << x_1 << "\t" << x_2 << endl;

        x_3 = (x_1+x_2)/2;
        // cout << x_3 << endl;

        while(abs(det(x_3))>accuracy)
        {
            counter++;
            if(det(x_1)*det(x_3)>0)
                x_1 = x_3;
            else
                x_2 = x_3;

            x_3 = (x_1+x_2)/2;
        }
        // cout << "\tx3 " << x_3 << endl;

        if(abs(solve[0]-x_3) > accuracy && abs(solve[1] - x_3) > accuracy) // sprawdzanie czy juz takich nie znalazl
        {
            // cout << "\t\tznalazlem " << x_3 << endl;
            solve[found] = x_3;
            found++;
        }
    }

    cout << "Bisekcja Iteracje " << counter << endl;
    cout << solve[0] << "\t" << solve[1] << "\t" << solve[2] << endl;

// Newton
        solve[0] = solve[1] = solve[2] = 0; 
        found = 0;
        counter = 0;

        while(found!=3)
        {
            do{
                x_1 = ( (double)rand() / (double)RAND_MAX )* (to-from) + from;
                x_2 = ( (double)rand() / (double)RAND_MAX )* (to-from) + from;
            }while(det(x_1)*det(x_2)>=0);
            // cout << x_1 << x_2 << endl;

            do{
                counter++;
                x_1 = x_2;
                x_2 = x_2 - ( det(x_2)/pochDet(x_2) );
            }while(abs(x_2 - x_1) >= accuracy);

            if(abs(solve[0]-x_2) > accuracy && abs(solve[1] - x_2) > accuracy) // sprawdzanie czy juz takich nie znalazl
            {
                // cout << "\t\tznalazlem " << x_2 << endl;
                found++;
                solve[found-1] = x_2;
            }
        }

        cout << "Newton Iteracje " << counter << endl;
        cout << solve[0] << "\t" << solve[1] << "\t" << solve[2] << endl;

// Siecznych

    solve[0] = solve [1] = solve[2] = 0;
    found = 0;
    from = -10., to = 10.;
    counter = 0;

    while(found!=3)
    {
        do{
            x_1 = ( (double)rand() / (double)RAND_MAX )* (to-from) + from;
            x_2 = ( (double)rand() / (double)RAND_MAX )* (to-from) + from;
        }while(det(x_1)*det(x_2)>=0);

        do{
            counter++;
            x_3 = ( det(x_1)*x_2 - det(x_2)*x_1 ) / (det(x_1) - det(x_2));
            x_1 = x_2;
            x_2 = x_3;
        }while (abs(det(x_3))>accuracy);

        if(abs(solve[0]-x_3) > accuracy && abs(solve[1] - x_3) > accuracy) // sprawdzanie czy juz takich nie znalazl
        {
            solve[found] = x_3;
            found++;
        }
    }

    cout << "Sieczne Iteracje " << counter << endl;
    cout << solve[0] << "\t" << solve[1] << "\t" << solve[2] << endl;

// Regula falsi

    solve[0] = solve[1] = solve[2] = 0; 
    found = 0;
    counter = 0;

    while( found != 3)
    {
        do{
                x_1 = ( (double)rand() / (double)RAND_MAX )* (to-from) + from;
                x_2 = ( (double)rand() / (double)RAND_MAX )* (to-from) + from;
        }while(det(x_1)*det(x_2)>=0);

        x_3 = ( x_1*det(x_2) - x_2*det(x_1) ) / (det(x_2) - det(x_1));

        while(abs(det(x_3))>accuracy)
        {
            counter++;
            if(det(x_1)*det(x_3)>=0)
                x_2 = x_1;
                
            x_1 = x_3;
            x_3 = ( x_1*det(x_2) - x_2*det(x_1) ) / (det(x_2) - det(x_1));
        }

        if(abs(solve[0]-x_3) > accuracy && abs(solve[1] - x_3) > accuracy) // sprawdzanie czy juz takich nie znalazl
        {
            // cout << "\t\tznalazlem " << x_3 << endl;
            solve[found] = x_3;
            found++;
        }
    }

    cout << "Regula falsi Iteracje " << counter << endl;
    cout << solve[0] << "\t" << solve[1] << "\t" << solve[2] << endl;

// Halleya

    solve[0] = solve[1] = solve[2] = 0; 
    found = 0;
    counter = 0;

    while(found!=3)
    {
        do{
            x_1 = ( (double)rand() / (double)RAND_MAX )* (to-from) + from;
            x_2 = ( (double)rand() / (double)RAND_MAX )* (to-from) + from;
        }while(det(x_1)*det(x_2)>=0);

        do{
            counter++;
            x_1 = x_2;
            x_2 = x_2 - ( 2*det(x_2)*pochDet(x_2) ) / ( 2*pochDet(x_2)*pochDet(x_2) - det(x_2)*poch2Det(x_2) );
        }while (abs(x_2 - x_1)>accuracy);

        if(abs(solve[0]-x_2) > accuracy && abs(solve[1] - x_2) > accuracy) // sprawdzanie czy juz takich nie znalazl
        {
            solve[found] = x_2;
            found++;
        }
    }

    cout << "Halleya Iteracje " << counter << endl;
    cout << solve[0] << "\t" << solve[1] << "\t" << solve[2] << endl;
}