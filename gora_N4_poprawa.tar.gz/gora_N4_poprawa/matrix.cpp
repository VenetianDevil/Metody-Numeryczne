#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    int N=1000;
    double h=0.01;
    double h_d = 1/(h*h);
    double h_pd = 1-(2/(h*h));
    double Diag[N], PodDiag[N], PodDiagDwa[N], y[N], f[N];

// po rozwiazaniu trzech pierwszych rownan z przelozonym ostatnim na gore
    y[0] = 1;
    y[1] = 0.666678;
    y[2] = 0.333289;

// uzipelnienie pozostalych czesci diagonal
    for(int i=5; i<N; i++)
    {
        Diag[i] = h_d;
        PodDiag[i] = h_pd;
        PodDiagDwa[i] = h_d;
    }
    PodDiag[4] = h_pd;
    Diag[4] = Diag[3] = h_d;

// uzupelnienie wektora wynikowego uwzgledniajac obliczone y[1] y[2]
    f[3] = -(h_d*y[1])-(h_pd*y[2]);
    f[4] = -h_d*y[2];

// obliczenie y[3] i y[4] z zaleznosci od powyzej nadanych wartosci wektora f
    y[3] = f[3]/Diag[3];
    y[4] = (f[4] - PodDiag[4]*y[3])/Diag[4];

// dalej kozystamy ze stworzonej zaleznosci obliczania kolejnych wyrazow wektora
    for(int i=5; i<N; i++)
    {
        y[i] = (-PodDiag[i]*y[i-1]-PodDiagDwa[i]*y[i-2])/Diag[i];
    }

    for(int i=0; i<N; i++)
    {
        cout << i*h << "\t" << y[i] << endl;
    }
}