#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

vector<double> mulMatrixVec(vector<vector<double>> A, vector<double> b)
{
    vector<double> result;
    vector<double> row;
    double a;
    for(int i=0; i<3; i++)
    {
        a=0;
        row = A.at(i);
        for(int j=0; j<3; j++)
        {
            a += row.at(j) * b.at(j);
        }
        result.push_back(a);
        row.clear();
    }
    return result;
}

vector<double> addVV(vector<double> x, vector<double> y)
{
    vector<double> sum;
    double a;
    for(int i=0; i<3; i++)
    {
        a = x.at(i) + y.at(i);
        sum.push_back(a);
    }
    return sum;
}

double mulVV(vector<double> a, vector<double> b)
{
    double r = 0;
    for(int i=0; i<3; i++)
    {
        r += a.at(i) * b.at(i);
    }
    return r;
}

vector<double> mulVecD(vector<double> x, double gamma)
{
    vector<double> multi;
    double a;
    for(int i=0; i<3; i++)
    {
        a = x.at(i) * gamma;
        multi.push_back(a);
    }
    return multi;
}

double Vlength (vector<double> x)
{
    double precision = 0;
    for(double i: x)
    {
        precision +=  i*i;
    }
    return sqrt(precision);
}


int main()
{
    double accuracy = 0.0000000001;
    vector<vector<double>> A = {{4, -1, 0}, {-1, 4, -1}, {0, -1, 4}};
    vector<double> b = {2, 6, 2};
    vector<double> x = {0, 0, 0};
    vector<double> r = b;
    vector<double> p = r;
    vector<double> rTemp;
    double alfa, beta;

    while(Vlength(r)>accuracy)
    {
        alfa = (mulVV(r, r))/(mulVV(p, mulMatrixVec(A, p)));
        rTemp = r;
        x = addVV(x, mulVecD(p, alfa));
        r = addVV(rTemp, mulVecD( mulMatrixVec(A, p), -alfa));
        beta = (mulVV(r, r))/(mulVV(rTemp, rTemp));
        p = (addVV(r, mulVecD(p, beta)));
    }

    cout << "Vector x: " << endl;

    for(auto m : x)
    {
        cout << m << endl;
    } 
}