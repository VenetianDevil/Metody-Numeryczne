#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[])
{
    double x = 1;
    double h = 0.0000000000000001;
    double f = -sin(x); // pochodna cos(x)
    double a;
    double b;
    double c;

    int zmienna = atoi(argv[1]);

    switch(zmienna)
    {
    //a
        case 1:
            while(h<=1)
            {
                a=(cos(x+h)-cos(x))/h;
                double bla=a-f;
                printf("%.16f\t%.16f\n",h, fabs(bla));
                h=1.1*h;
            }
        break;

    //b
        case 2:
            while(h<=1)
            {
                b=(cos(x+h)-cos(x-h))/(2*h);
                double blb=b-f;
                printf("%.16f\t%.16f\n",h, fabs(blb));
                h=1.1*h;

            }
        break;

    //c
        case 3:
            while(h<=1)
            {
                c=(-cos(x+2*h)+8*cos(x+h)-8*cos(x-h)+cos(x-2*h))/(12*h);
                double blc=c-f;
                printf("%.16f\t%.16f\n",h, fabs(blc));
                h=1.1*h;
            }
        break;
    }
    return 0;
}