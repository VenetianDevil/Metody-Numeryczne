#include <iostream>
#include <cmath>
#include <complex>
using namespace std;

int main()
{
    double accuracy = 0.000001;
    double sqrt3 = sqrt(3);
    double square = 3;
    
    complex<double> z1(1.0);
    complex<double> z2(-0.5, sqrt3/2);
    complex<double> z3(-0.5, -sqrt3/2);

    for(double i = -square; i<square; i+=0.01)
    {
        for(double j = -square; j<square; j+=0.01)
        {
            complex<double> z(i, j);
            while(abs(z*z*z-1.0)>accuracy)
            {
                z = z - (z*z*z - 1.0)/(3.0*z*z);
            }
            if(abs(z-z1)<accuracy)  cout << i << "\t" << j << "\t" << 0 << endl;
            else if (abs(z-z2)<accuracy) cout << i << "\t" << j << "\t" << 1 << endl;
            else if (abs(z-z3)<accuracy) cout << i << "\t" << j << "\t" << 2 << endl;
        }
    }
}