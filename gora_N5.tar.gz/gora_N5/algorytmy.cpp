#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

int N = 3;
vector<double> mulMatrixVec(vector<vector<double>> A, vector<double> b);
vector<double> addVV(vector<double> x, vector<double> y);
vector<double> mulVecD(vector<double> x, double gamma);
double Vlength (vector<double> x);

int main()
{
// implementacja macierzy i wektorow

    double accuracy = pow(10, -10);
    vector<vector<double>> A = {{4, -1, 0}, {-1, 4, -1}, {0, -1, 4}};
    vector<double> b = {2, 6, 2};
    vector<double> x_n = {0, 0, 0}, x_n1 = {0, 0, 0}; //x_n - x^(n);    x_n1 - x^(n+1);
    double gamma = 0.25;
    double i=0;
    double precision;

// metoda relaksacyjna Richardsona -----------------------------------------------------------

    do{
        x_n = x_n1;
        x_n1 = addVV(x_n, mulVecD(addVV(b, mulVecD(mulMatrixVec(A, x_n), -1)), gamma));
        i++;
        precision = Vlength(addVV(x_n1, mulVecD(x_n, -1)));
    }while(precision>accuracy);

    cout << "Metoda relaksacji Richardsona wykonana " << i << " iteracjami" << endl;
    cout << "Vector x_n1: " << endl;

    for(auto m : x_n1)
    {
        cout << m << endl;
    } 

// metoda Jacobiego --------------------------------------------------------------------------

    vector<vector<double>> R = {{0, -1, 0}, {-1, 0, -1}, {0, -1, 0}};
    x_n = {0, 0, 0}, x_n1 = {0, 0, 0};
    i=0;

    do{
        x_n = x_n1;

        i++;
        x_n1 = mulVecD(addVV(b, mulVecD(mulMatrixVec(R, x_n), -1)) ,0.25);

        precision = Vlength(addVV(x_n1, mulVecD(x_n, -1)));
    }while(precision>accuracy);

    cout << "Metoda Jacobiego wykonana " << i << " iteracjami" << endl;
    cout << "Vector x_n1: " << endl;

    for(auto m : x_n1)
    {
        cout << m << endl;
    } 

// Gaussa-Seidla ------------------------------------------------------------

    x_n = {0, 0, 0}, x_n1 = {0, 0, 0};
    i=0;

    do{
        x_n = x_n1;
        i++;

        for(int k = 0; k<N; k++)
        {
            double sum=0;
            for(int j =0; j<N; j++)
            {
                if(j<k)
                {
                    sum += A.at(k).at(j)*x_n1.at(j);
                }
                if(j>k)
                {
                    sum+= A.at(k).at(j)*x_n.at(j);
                }
            }
            x_n1.at(k) = (b.at(k)-sum)/A.at(k).at(k);
        }
        precision = Vlength(addVV(x_n1, mulVecD(x_n, -1)));
    }while(precision>accuracy);

    cout << "Metoda Gaussa_Seidela wykonana " << i << " iteracjami" << endl;
    cout << "Vector x_n1: " << endl;

    for(auto m : x_n1)
    {
        cout << m << endl;
    }

    x_n = {0, 0, 0}, x_n1 = {0, 0, 0};
    i=0;
    double omega = 1.05;

    do{
        x_n = x_n1;
        i++;

        for(int k = 0; k<N; k++)
        {
            double sum=0;
            for(int j =0; j<N; j++)
            {
                if(j<k)
                {
                    sum += A.at(k).at(j)*x_n1.at(j);
                }
                if(j>k)
                {
                    sum+= A.at(k).at(j)*x_n.at(j);
                }
            }
            x_n1.at(k) = (1-omega)*x_n.at(k) + omega*(b.at(k)-sum)/A.at(k).at(k);
        }
        precision = Vlength(addVV(x_n1, mulVecD(x_n, -1)));
    }while(precision>accuracy);

    cout << "Metoda SOR wykonana " << i << " iteracjami" << endl;
    cout << "Vector x_n1: " << endl;

    for(auto m : x_n1)
    {
        cout << m << endl;
    }
}

vector<double> mulMatrixVec(vector<vector<double>> A, vector<double> b)
{
    vector<double> result;
    vector<double> row;
    double a;
    for(int i=0; i<N; i++)
    {
        a=0;
        row = A.at(i);
        for(int j=0; j<N; j++)
        {
            a += row.at(j) * b.at(j);
        }
        result.push_back(a);
        row.clear();
    }
    return result;
}

vector<double> addVV(vector<double> x, vector<double> y)
{
    vector<double> sum;
    double a;
    for(int i=0; i<N; i++)
    {
        a = x.at(i) + y.at(i);
        sum.push_back(a);
    }
    return sum;
}

vector<double> mulVecD(vector<double> x, double gamma)
{
    vector<double> multi;
    double a;
    for(int i=0; i<N; i++)
    {
        a = x.at(i) * gamma;
        multi.push_back(a);
    }
    return multi;
}

double Vlength (vector<double> x)
{
    double precision = 0;
    for(double i: x)
    {
        precision +=  i*i;
    }
    return sqrt(precision);
}