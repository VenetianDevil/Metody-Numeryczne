#include <iostream>
#include <cmath>

using namespace std;

const int N = 100;
double h = 10.0/(N-1);
double dane [N][N];

double find (int n, int m)
{
    if(n==0 || n==N-1 || m==N-1)
    {
      return 0;
    }
    else if(m==0)
    {
      return 1 - (fabs(h*n - 5)/5);
    }
    else if((((h*n - 3)*(h*n - 3))+((h*m -7)*(h*m - 7))) < 0.2)
    {
        return 1;                
    }
    else if((((h*n - 8)*(h*n - 8))+((h*m -7)*(h*m - 7))) < 0.2)
    {
        return 2;                
    }
    return -1;
}

double Rest (int n, int m)
{
    double left=-1, right=-1, up=-1, down=-1;
    int i=n, j=m;
    int k =4;
    int k_max = 4*4*4*4*4*4*4*4*4*4;
    while(left==-1 && k<k_max)
    {
        if(dane[i][j-1]!=-1)
        {
            left = dane[i][j-1]/k;
        }
        k*=4;
        j--;
    }

    if(left==-1)
    {
        left=0;
    }

    j=m;
    k =4;
    while(right==-1 && k<k_max)
    {
        if(dane[i][j+1]!=-1)
        {
            right = dane[i][j+1]/k;
        }
        k*=4;
        j++;
    }

    if(right==-1)
    {
        right=0;
    }

    j=m;
    k =4;
    while(down==-1 && k<k_max)
    {
        if(dane[i-1][j]!=-1)
        {
            down = dane[i-1][j]/k;
        }
        k*=4;
        i--;
    }

    if(down==-1)
    {
        down=0;
    }

    i=n;
    k =4;
    while(up==-1 && k<k_max)
    {
        if(dane[i+1][j]!=-1)
        {
            up = dane[i+1][j]/k;
        }
        k*=4;
        i++;
    }

    if(up==-1)
    {
        up=0;
    }

    return left+right+up+down;
}

int main()
{
    for(int n = 0; n<N; n++)
    {
        for(int m = 0; m<N; m++)
        {
            dane[n][m] = find(n,m);
        }
    }

    for(int n = 0; n<N; n++)
    {
        for(int m = 0; m<N; m++)
        {
            if(dane[n][m]==-1)
            {
                dane[n][m] = Rest(n,m);
            }
        }
    }

    int i=1;
    while(i<N*N)
    {
        for(int n = 1; n<N-1; n++)
        {
            for(int m = 1; m<N-1; m++)
            {
                if(dane[n][m]!=1 && dane[n][m]!=2)
                {
                    dane[n][m] = (dane[n+1][m] + dane[n-1][m] + dane[n][m+1] + dane[n][m-1])/4;
                }
            }
        }
        i++;
    }

    for(int n = 0; n<N; n++)
    {
        for(int m = 0; m<N; m++)
        {
            cout << n*h << "\t" << m*h << "\t" << dane[n][m] << endl;
        }
    }

}
