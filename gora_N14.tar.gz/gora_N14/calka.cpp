#include <iostream>
#include <cmath>

using namespace std;

double function (double x)
{
    double sinus = sin(x);
    return exp(sinus*sinus);
}

int main()
{
    double accuracy = 0.000001;
    double xp = -M_PI/2, xk = M_PI/2; //przedzial
    double dx = (xk-xp)/2;
    double area = 0;
    double ends = (function(xp) + function(xk));

// Metoda Trapezow
    double xi = xp + dx;
    double last;
    double next = function(xi);
    area = dx*(ends/2 + next);
    do{
        last = area;
        xi = xp + dx/2;
        while(xi<xk)
        {
            next += function(xi);
            xi += dx; 
        }
        dx /= 2;
        area = dx*(ends/2 + next);
    }while(abs(area - last)>accuracy);

    cout << "Metoda trapezow " << area << endl;

//Metoda Simpsona
    double middle, boundry;
    last = 0;
    dx = (xk - xp) / 2;
    xi= xp + dx;
    middle = function(xi);
    boundry = 0;
    area = (dx/3) * (ends + 4*middle);

    do{
        last = area;
        boundry += middle;
        dx /= 2;
        xi = xp + dx;
        middle = 0;
        while(xi < xk)
        {
            middle += function(xi);
            xi += dx + dx;
        }
        area = (dx/3) * (ends + 4*middle + 2*boundry);
    }while(abs(area-last)>accuracy);

    cout << "Metoda Simpsona " << area << endl;

// Metoda 3/8
    last = 0;
    dx = (xk - xp) / 3;
    xi= xp + dx;
    boundry = 0;
    middle = function(xi) + function(xi + dx);
    area = (3*dx/8) * (ends + 3*middle);

    do{
        last = area;
        boundry += middle;
        middle = 0;
        xi = xp + dx/3;
        while(xi<xk)
        {
            middle += function(xi) + function(xi+ (dx/3));
            xi += dx;
        }
        dx /= 3;
        area = (3*dx/8) * (ends + 3*middle + 2*boundry);
    }while(abs(area - last) > accuracy);

    cout << "Metoda 3/8\t" << area << endl;
}