#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

int N = 32;

double function1 (double x)
{
    return 1/(1+(x*x));
}

double function2 (double x)
{
    return exp(-x*x);
}

double sinc(double x)
{
    if(x!=0)
    return sin(x)/x;
    return 1;
}

int main()
{
    double f1_value[N], f2_value[N], x_n[N];
    double from = -5, to = 5;
    double dx = (to-from)/(N-1); // odstep pomiedzy każdym z N punktów (wliczamy skrajne do N)
    double h = 10/((double)N-1);

// wyliczanie wartości funkcji dla punktow

    for(int i = 0; i<N; i++)
    {
        f1_value[i] = function1(from + i*dx);
        f2_value[i] = function2(from + i*dx);
        x_n[i] = -5 + (h*i);
    }

// szukanie wielonmianow
    double  polynomial_1, polynomial_2;
    double sinus, x_sin;
    double sigma_1, sigma_2, sigma1_max=0, sigma2_max=0;
    h = M_PI/h;

    for(double x = -7; x<=7; x+=0.1)
    {
        polynomial_1 = polynomial_2 =0;
        if(x>=-5 && x <=5)
        {
            for(int i=0; i<N; i++)
            {
                x_sin = h*(x-x_n[i]); 
                sinus = sinc(x_sin);
                polynomial_1 += f1_value[i]*sinus;
                polynomial_2 += f2_value[i]*sinus;
            }
        }
        
        sigma_1 = abs(polynomial_1 - function1(x));
        sigma_2 = abs(function2(x) - polynomial_2);
        if(sigma_1>sigma1_max)
            sigma1_max = sigma_1;

        if(sigma_2>sigma2_max)
            sigma2_max = sigma_2;
    
        cout << x << "\t" << setprecision(15) << polynomial_1 << endl;
        // cout << x << "\t" << setprecision(15) << polynomial_2 << endl;
    }
    // cout << setprecision(15) << sigma1_max << "\t" << sigma2_max << endl;
}