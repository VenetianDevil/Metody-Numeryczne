#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

int N =55;

double function1 (double x)
{
    return 1/(1+(x*x));
}

double function2 (double x)
{
    return exp(-x*x);
}

int main()
{
    double f1_value[N], f2_value[N];
    double from = -5, to = 5;
    double dx = (to-from)/(N-1); // odstep pomiedzy każdym z N punktów (wliczamy skrajne do N)
    int k; //zmienna do odczytywania wartosci tablicy

// wyliczanie wartości funkcji dla punktow

    for(int i = 0; i<N; i++)
    {
        f1_value[i] = function1(from + i*dx);
        f2_value[i] = function2(from + i*dx);
    }

// szukanie wielonmianow

    double Lagrange_1, Lagrange_2;
    double polynomial;
    bool equal;
    double sigma_1, sigma_2, sigma1_max=0, sigma2_max=0;

    for(double x = -20; x<=20; x+=0.1)
    {
        Lagrange_1 = Lagrange_2 = 0;
        k=0;
        equal = false;
        for(double i=from; i<=to; i+=dx)
        {
            if(x!=i && equal==false) // bo warunek na wybor x: x != x_i
            {
                polynomial = 1;
                for(double j=from; j<=to; j+=dx)
                {
                    if(i!=j)
                        polynomial *= (x-j)/(i-j);
                }
                Lagrange_1 += f1_value[k]*polynomial;
                Lagrange_2 += f2_value[k++]*polynomial;
            }
            else if(equal == false)  //zeby wykonalo sie tylko raz, gdy x=x_i;
            {
                equal = true; // zapewnienie odrzucenia danego x poniewaz byl rowny jakiemus x_i
            }
        }
        
        sigma_1 = abs(Lagrange_1 - function1(x));
        sigma_2 = abs(function2(x) - Lagrange_2);
        if(sigma_1>sigma1_max)
            sigma1_max = sigma_1;

        if(sigma_2>sigma2_max)
            sigma2_max = sigma_2;
    
        if(equal==false)
        // cout << x << "\t" << setprecision(15) <<Lagrange_1<< endl;
        cout << x << "\t" << setprecision(15) << Lagrange_2 << endl;
    }

        // cout << setprecision(15) << sigma1_max << "\t" << sigma2_max << endl;
}