#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

int N = 90;

double function1 (double x)
{
    return 1/(1+(x*x));
}

double function2 (double x)
{
    return exp(-x*x);
}

void find_xi(double xsi[], double f_value[], double h)
{
    double beta[N], gamma[N], poddiag = 1.0, diag = 4.0, mianownik, f[N];
    xsi[0] = xsi[N-1] = 0;
    beta[0] = -1.0/diag;
    h = 6.0/(h*h);

    for(int i=1; i<N-1; i++)
    {
        f[N] = h*(f_value[i-1] + 2*f_value[i] + f_value[i+1]);
    }

    gamma[0] = f[0] / diag;

    for(int i = 1; i<N-1; i++)
    {
        mianownik = (poddiag*beta[i-1]) + diag;
        beta[i] = -1/mianownik;
        gamma[i] = (f[i] - (poddiag*f[i-1]))/mianownik;
    }

    for(int i=N-2; i>=0; i--)
    {
        xsi[i] = beta[i]*xsi[i+1] + gamma[i];
    }
}

int main()
{
    double f1_value[N], f2_value[N], xi_1[N], xi_2[N];
    double from = -5, to = 5;
    double dx = (to-from)/(N-1); // odstep pomiedzy każdym z N punktów (wliczamy skrajne do N)
    int k = 0; //zmienna do odczytywania wartosci tablicy

// wyliczanie wartości funkcji i pochodnych dla punktow

    for(int i = 0; i<N; i++)
    {
        f1_value[i] = function1(from + i*dx);
        f2_value[i] = function2(from + i*dx);
    }

    find_xi(xi_1, f1_value, dx);
    find_xi(xi_2, f2_value, dx);

// szukanie wielonmianow

    double polynomial_1, polynomial_2, A, B, C, D, x_left = from, x = from;
    double sigma_1, sigma_2, sigma1_max=0, sigma2_max=0;

        for(double i=from+dx; i<to; i+=dx) // x_right
        {
            while(x>=x_left && x<i)
            {
                A = (i- x)/dx;
                B = (x - x_left)/dx;
                C = (1.0/6.0)*(A*A*A - A)*dx*dx;
                D = (1.0/6.0)*(B*B*B - B)*dx*dx;

                polynomial_1 = A*f1_value[k] + B*f1_value[k+1] + C*xi_1[k] + D*xi_1[k+1];
                polynomial_2 = A*f2_value[k] + B*f2_value[k+1] + C*xi_2[k] + D*xi_2[k+1];

                x += 0.1;

                sigma_1 = abs(polynomial_1 - function1(x));
                sigma_2 = abs(function2(x) - polynomial_2);
                if(sigma_1>sigma1_max)
                    sigma1_max = sigma_1;

                if(sigma_2>sigma2_max)
                    sigma2_max = sigma_2;
            
                // cout << x << "\t" << setprecision(15) << polynomial_1 << endl;
                cout << x << "\t" << setprecision(15) << polynomial_2 << endl;
            }
            k++;
            x_left = i;
        }
        
        // cout << setprecision(15) << sigma1_max << "\t" << sigma2_max << endl;
}