#include <iostream>
#include <cmath>

using namespace std;

int N=1000;

int main()
{
    double NadDiag[N], Diag[N], PodDiag[N], x[N], f[N];
    double h = 0.01;
    double h_ac = 1/(h*h);
    double h_b = 1-(2/(h*h));

    for(int i=1; i<N-1 ;i++)
    {
        NadDiag[i] = h_ac;
        Diag[i] = h_b;
        PodDiag[i] = h_ac;
    }

    Diag[0] = PodDiag[N-1] = f[0] = 1;
    NadDiag[0] = NadDiag[N-1] = 0;
    Diag[N-1] = -2;
    f[N-1] = -1;

    //beta przetrzymywana w naddiagonali bo jej wartości wiecej nie sa uzywane, tylko do obliczenia bety
    //gamma w wektorze wtrazow wolnych bo jej wartosci wiecej nie sa uzywane, tylko do obliczania gammy

    NadDiag[0] /= -Diag[0]; //beta 1
    f[0] /= Diag[0]; // gamma 1
    double mianownik = 0;
    for(int i=1; i<N; i++)
    {
        mianownik = (PodDiag[i]*NadDiag[i-1])+Diag[i];
        NadDiag[i] /= -mianownik;
        f[i] = (f[i]-(PodDiag[i]*f[i-1]))/mianownik;
    }

    //teraz liczymy wektor wynikowy od konca, poniewaz dodajemy element nastepny w kolejnosci

    x[N-1] = f[N-1];
    for(int i=N-2; i>=0; i--)
    {
        x[i] = NadDiag[i]*x[i+1] + f[i];
    }

    for(int i=0; i<N; i++)
    {
        cout << i*h << "\t" << x[i] << endl;
        // cout << PodDiag[i] << "\t" << Diag[i] << "\t" << NadDiag[i] << "\t" << f[i] << endl;
    }
    return 0;
}