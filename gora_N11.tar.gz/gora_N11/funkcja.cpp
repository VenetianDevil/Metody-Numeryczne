#include <iostream>
using namespace std;

int main()
{
    int N = 1000;
    double x_0 = 0.1;
    double k=2;

    while(k<=4)
    {
        for(int i=0; i<N; i++)
        {
            cout << k << "\t" << x_0 << endl;
            x_0 = k*x_0*(1-x_0);
        }
        k += 0.01;
    }
}